package com.visshnu.marketrisk;

import com.visshnu.marketrisk.calculations.RiskCalculations;
import com.visshnu.marketrisk.db.CsvReader;
import com.visshnu.marketrisk.model.PriceData;

import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter path to CSV file (e.g., AAPL_timeseries.csv):");
        String csvPath = scanner.nextLine();

        try {
            CsvReader reader = new CsvReader();
            List<PriceData> priceDataList = reader.readPriceData(csvPath);

            List<Double> prices = priceDataList.stream()
                    .map(PriceData::getClosePrice)
                    .collect(Collectors.toList());

            List<Double> dailyReturns = RiskCalculations.computeDailyReturns(prices);
            double annVol = RiskCalculations.annualizedVolatility(dailyReturns);
            double histVaR = RiskCalculations.historicalVaR(dailyReturns, 0.95);
            double paramVaR = RiskCalculations.parametricVaR(dailyReturns, 0.95);

            System.out.println("\nResults:");
            System.out.printf("Annualized Volatility: %.2f%%%n", annVol * 100);
            System.out.printf("Historical VaR (95%%): %.2f%%%n", histVaR * 100);
            System.out.printf("Parametric VaR (95%%): %.2f%%%n", paramVaR * 100);

        } catch (Exception e) {
            System.err.println("Error reading file or calculating risk: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
