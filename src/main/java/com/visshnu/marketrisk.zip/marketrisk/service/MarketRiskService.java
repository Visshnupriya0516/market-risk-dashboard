package com.visshnu.marketrisk.service;
import com.visshnu.marketrisk.api.MarketDataApiClient;
import com.visshnu.marketrisk.calculations.RiskCalculations;
import com.visshnu.marketrisk.db.CsvReader;
import com.visshnu.marketrisk.model.PriceData;

import java.util.List;
import java.util.stream.Collectors;
public class MarketRiskService {
    private CsvReader csvReader = new CsvReader();
    private MarketDataApiClient apiClient = new MarketDataApiClient();

    public List<PriceData> getPricesFromCsv(String csvFilePath) throws Exception {
        return csvReader.readPriceData(csvFilePath);
    }

    // Future: parse API response, convert to PriceData list
    public List<PriceData> getPricesFromApi(String apiUrl) throws Exception {
        String jsonResponse = apiClient.getApiResponse(apiUrl);
        // TODO: parse JSON to List<PriceData> (use Jackson or Gson)
        throw new UnsupportedOperationException("API parsing not implemented yet.");
    }

    public void analyzeAndPrintRiskMetrics(List<PriceData> priceDataList) {
        List<Double> prices = priceDataList.stream()
                .map(PriceData::getClosePrice)
                .collect(Collectors.toList());

        List<Double> dailyReturns = RiskCalculations.computeDailyReturns(prices);
        double annVol = RiskCalculations.annualizedVolatility(dailyReturns);
        double histVaR = RiskCalculations.historicalVaR(dailyReturns, 0.95);
        double paramVaR = RiskCalculations.parametricVaR(dailyReturns, 0.95);

        System.out.printf("Annualized Volatility: %.2f%%%n", annVol * 100);
        System.out.printf("Historical VaR (95%%): %.2f%%%n", histVaR * 100);
        System.out.printf("Parametric VaR (95%%): %.2f%%%n", paramVaR * 100);
    }
}
