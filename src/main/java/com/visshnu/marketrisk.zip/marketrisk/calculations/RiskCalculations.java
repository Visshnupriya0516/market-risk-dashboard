package com.visshnu.marketrisk.calculations;
import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

import java.util.ArrayList;
import java.util.List;
public class RiskCalculations {
    // Compute daily returns from closing prices
    public static List<Double> computeDailyReturns(List<Double> prices) {
        List<Double> returns = new ArrayList<>();
        for (int i = 1; i < prices.size(); i++) {
            double ret = (prices.get(i) - prices.get(i - 1)) / prices.get(i - 1);
            returns.add(ret);
        }
        return returns;
    }

    // Annualized volatility = stddev(daily returns) * sqrt(252)
    public static double annualizedVolatility(List<Double> dailyReturns) {
        DescriptiveStatistics stats = new DescriptiveStatistics();
        for (double r : dailyReturns) {
            stats.addValue(r);
        }
        double dailyStd = stats.getStandardDeviation();
        return dailyStd * Math.sqrt(252);
    }

    // Historical VaR (simple quantile)
    public static double historicalVaR(List<Double> dailyReturns, double confidence) {
        DescriptiveStatistics stats = new DescriptiveStatistics();
        for (double r : dailyReturns) {
            stats.addValue(r);
        }
        double percentile = (1 - confidence) * 100;
        return stats.getPercentile(percentile);
    }

    // Parametric VaR assuming normal distribution
    public static double parametricVaR(List<Double> dailyReturns, double confidence) {
        DescriptiveStatistics stats = new DescriptiveStatistics();
        for (double r : dailyReturns) {
            stats.addValue(r);
        }
        double mean = stats.getMean();
        double std = stats.getStandardDeviation();
        org.apache.commons.math3.distribution.NormalDistribution norm =
                new org.apache.commons.math3.distribution.NormalDistribution();
        double z = norm.inverseCumulativeProbability(1 - confidence);
        // VaR is negative of (mean + z * std)
        return -(mean + z * std);
    }
}
