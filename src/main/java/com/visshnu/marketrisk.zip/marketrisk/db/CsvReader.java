package com.visshnu.marketrisk.db;
import com.opencsv.CSVReader;
import com.visshnu.marketrisk.model.PriceData;

import java.io.FileReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
public class CsvReader {
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public List<PriceData> readPriceData(String filePath) throws Exception {
        List<PriceData> prices = new ArrayList<>();
        try (CSVReader reader = new CSVReader(new FileReader(filePath))) {
            String[] nextLine;
            reader.readNext(); // Skip header
            while ((nextLine = reader.readNext()) != null) {
                LocalDate date = LocalDate.parse(nextLine[0], formatter);
                double closePrice = Double.parseDouble(nextLine[1]);
                prices.add(new PriceData(date, closePrice));
            }
        }
        return prices;
    }
}
