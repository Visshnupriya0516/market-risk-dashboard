package com.visshnu.marketrisk.model;
import java.time.LocalDate;
public class PriceData {

        private LocalDate date;
        private double closePrice;

        public PriceData(LocalDate date, double closePrice) {
            this.date = date;
            this.closePrice = closePrice;
        }

        public LocalDate getDate() {
            return date;
        }

        public double getClosePrice() {
            return closePrice;
        }

        @Override
        public String toString() {
            return "PriceData{" + "date=" + date + ", closePrice=" + closePrice + '}';
        }
    }

